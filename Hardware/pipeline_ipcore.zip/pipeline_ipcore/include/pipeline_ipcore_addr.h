/*
 * File Name:         codegen\ipcore\pipeline_ipcore_v1_0\include\pipeline_ipcore_addr.h
 * Description:       C Header File
 * Created:           2025-06-07 08:43:37
*/

#ifndef PIPELINE_IPCORE_H_
#define PIPELINE_IPCORE_H_

#define  IPCore_Reset_pipeline_ipcore                           0x0  //write 0x1 to bit 0 to reset IP core
#define  IPCore_Enable_pipeline_ipcore                          0x4  //enabled (by default) when bit 0 is 0x1
#define  IPCore_PacketSize_AXI4_Stream_Master_pipeline_ipcore   0x8  //Packet size for AXI4-Stream Master interface, the default value is 1024. The TLAST output signal of the AXI4-Stream Master interface is generated based on the packet size.
#define  IPCore_Timestamp_pipeline_ipcore                       0xC  //contains unique IP timestamp (yymmddHHMM): 2506070843

#endif /* PIPELINE_IPCORE_H_ */
